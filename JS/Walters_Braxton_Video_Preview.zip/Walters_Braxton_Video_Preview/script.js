

function playVid(element) {
    element.play();
}

function pause(element) {
    element.pause();
}